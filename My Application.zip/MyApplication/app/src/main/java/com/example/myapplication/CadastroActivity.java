package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import java.util.Calendar;

public class CadastroActivity extends Activity {

    private EditText editNome, editDescricao, editHorario;
    private MedicamentoDBHelper dbHelper;

    private boolean isEdicao = false;
    private int medicamentoId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        editNome = findViewById(R.id.editNome);
        editDescricao = findViewById(R.id.editDescricao);
        editHorario = findViewById(R.id.editHorario);
        Button btnSalvar = findViewById(R.id.btnSalvar);

        dbHelper = new MedicamentoDBHelper(this);

        // Verifica se está editando
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("id")) {
            isEdicao = true;
            medicamentoId = intent.getIntExtra("id", -1);
            editNome.setText(intent.getStringExtra("nome"));
            editDescricao.setText(intent.getStringExtra("descricao"));
            editHorario.setText(intent.getStringExtra("horario"));
        }

        btnSalvar.setOnClickListener(view -> {
            String nome = editNome.getText().toString().trim();
            String descricao = editDescricao.getText().toString().trim();
            String horario = editHorario.getText().toString().trim();

            if (nome.isEmpty() || horario.isEmpty()) {
                Toast.makeText(this, "Preencha nome e horário!", Toast.LENGTH_SHORT).show();
                return;
            }

            if (isEdicao) {
                dbHelper.atualizarMedicamento(medicamentoId, nome, descricao, horario, false);
                cancelarAlarme(medicamentoId);
                agendarAlarme(nome, horario, medicamentoId);
                Toast.makeText(this, "Medicamento atualizado!", Toast.LENGTH_SHORT).show();
            } else {
                long id = dbHelper.inserirMedicamento(nome, descricao, horario);
                if (id != -1) {
                    agendarAlarme(nome, horario, (int) id);
                    Toast.makeText(this, "Medicamento salvo!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Erro ao salvar", Toast.LENGTH_SHORT).show();
                }
            }

            finish();
        });
    }

    @SuppressLint("ScheduleExactAlarm")
    private void agendarAlarme(String nome, String horario, int requestCode) {
        try {
            String[] partes = horario.split(":");
            int hora = Integer.parseInt(partes[0]);
            int minuto = Integer.parseInt(partes[1]);

            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.HOUR_OF_DAY, hora);
            calendar.set(Calendar.MINUTE, minuto);
            calendar.set(Calendar.SECOND, 0);

            if (calendar.getTimeInMillis() < System.currentTimeMillis()) {
                calendar.add(Calendar.DAY_OF_MONTH, 1);
            }

            Intent intent = new Intent(this, AlarmReceiver.class);
            intent.putExtra("nome", nome);

            PendingIntent pendingIntent = PendingIntent.getBroadcast(
                    this, requestCode, intent, PendingIntent.FLAG_IMMUTABLE
            );

            AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
            if (alarmManager != null) {
                alarmManager.setExact(
                        AlarmManager.RTC_WAKEUP,
                        calendar.getTimeInMillis(),
                        pendingIntent
                );
                // Para repetição diária, troque por:
                // alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Erro ao agendar alarme", Toast.LENGTH_SHORT).show();
        }
    }

    private void cancelarAlarme(int requestCode) {
        Intent intent = new Intent(this, AlarmReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this, requestCode, intent, PendingIntent.FLAG_IMMUTABLE
        );
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        if (alarmManager != null) {
            alarmManager.cancel(pendingIntent);
        }
    }
}
