package com.example.myapplication;

public class Medicamento {
    public int id;
    public String nome;
    public String descricao;
    public String horario;
    public boolean consumido;

    public Medicamento() {
    }
}
