package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.*;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class MainActivity extends Activity {

    private RecyclerView recyclerView;
    private MedicamentoDBHelper dbHelper;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        Button btnAdicionar = findViewById(R.id.btnAdicionar);

        dbHelper = new MedicamentoDBHelper(this);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        carregarLista();

        btnAdicionar.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CadastroActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        carregarLista();
    }

    private void carregarLista() {
        List<Medicamento> listaMedicamentos = dbHelper.listarMedicamentos();
        MedicamentoAdapter adapter = new MedicamentoAdapter(this, listaMedicamentos, dbHelper);
        recyclerView.setAdapter(adapter);
    }
}
