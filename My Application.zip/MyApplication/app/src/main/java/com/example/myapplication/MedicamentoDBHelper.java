package com.example.myapplication;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;

import java.util.ArrayList;
import java.util.List;

public class MedicamentoDBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "medicamentos.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABELA = "medicamentos";
    private static final String COL_ID = "id";
    private static final String COL_NOME = "nome";
    private static final String COL_DESC = "descricao";
    private static final String COL_HORARIO = "horario";
    private static final String COL_CONSUMIDO = "consumido";

    public MedicamentoDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE " + TABELA + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_NOME + " TEXT NOT NULL, " +
                COL_DESC + " TEXT, " +
                COL_HORARIO + " TEXT NOT NULL, " +
                COL_CONSUMIDO + " INTEGER DEFAULT 0)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABELA);
        onCreate(db);
    }

    // Inserir novo medicamento
    public long inserirMedicamento(String nome, String descricao, String horario) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put(COL_NOME, nome);
        valores.put(COL_DESC, descricao);
        valores.put(COL_HORARIO, horario);
        valores.put(COL_CONSUMIDO, 0);
        return db.insert(TABELA, null, valores);
    }

    // Atualizar medicamento existente
    public void atualizarMedicamento(int id, String nome, String descricao, String horario, boolean consumido) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put(COL_NOME, nome);
        valores.put(COL_DESC, descricao);
        valores.put(COL_HORARIO, horario);
        valores.put(COL_CONSUMIDO, consumido ? 1 : 0);
        db.update(TABELA, valores, COL_ID + " = ?", new String[]{String.valueOf(id)});
    }

    // Excluir medicamento
    public void excluirMedicamento(int id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABELA, COL_ID + " = ?", new String[]{String.valueOf(id)});
    }

    // Buscar todos os medicamentos
    public List<Medicamento> listarMedicamentos() {
        List<Medicamento> lista = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABELA + " ORDER BY " + COL_HORARIO, null);

        if (cursor.moveToFirst()) {
            do {
                Medicamento m = new Medicamento();
                m.id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID));
                m.nome = cursor.getString(cursor.getColumnIndexOrThrow(COL_NOME));
                m.descricao = cursor.getString(cursor.getColumnIndexOrThrow(COL_DESC));
                m.horario = cursor.getString(cursor.getColumnIndexOrThrow(COL_HORARIO));
                m.consumido = cursor.getInt(cursor.getColumnIndexOrThrow(COL_CONSUMIDO)) == 1;
                lista.add(m);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return lista;
    }
}
