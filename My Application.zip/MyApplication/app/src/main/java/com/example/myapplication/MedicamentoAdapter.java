package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MedicamentoAdapter extends RecyclerView.Adapter<MedicamentoAdapter.ViewHolder> {

    private ArrayList<Medicamento> listaMedicamentos;
    private final Context context;
    private final List<Medicamento> lista;
    private final MedicamentoDBHelper dbHelper;

    public MedicamentoAdapter(Context context, List<Medicamento> lista, MedicamentoDBHelper dbHelper) {
        this.context = context;
        this.lista = lista;
        this.dbHelper = dbHelper;
    }

    @NonNull
    @Override
    public MedicamentoAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_medicamento, parent, false);
        return new ViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull MedicamentoAdapter.ViewHolder holder, int position) {
        Medicamento m = lista.get(position);

        holder.txtNome.setText(m.nome);
        holder.txtHorario.setText("Horário: " + m.horario);
        holder.txtDescricao.setText(m.descricao);

        if (m.consumido) {
            holder.itemView.setBackgroundColor(0xFFE0FFE0); // Verde claro
        } else {
            holder.itemView.setBackgroundColor(0xFFFFFFFF); // Branco
        }

        holder.btnConsumido.setText(m.consumido ? "✓ Tomado" : "Marcar como tomado");

        holder.btnConsumido.setOnClickListener(v -> {
            dbHelper.atualizarMedicamento(m.id, m.nome, m.descricao, m.horario, !m.consumido);
            m.consumido = !m.consumido;
            notifyItemChanged(position);
        });

        holder.itemView.setOnLongClickListener(v -> {
            dbHelper.excluirMedicamento(m.id);
            lista.remove(position);
            notifyItemRemoved(position);
            return true;
        });

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, CadastroActivity.class);
            intent.putExtra("id", m.id);
            intent.putExtra("nome", m.nome);
            intent.putExtra("descricao", m.descricao);
            intent.putExtra("horario", m.horario);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }

    public ArrayList<Medicamento> getListaMedicamentos() {
        return listaMedicamentos;
    }

    public void setListaMedicamentos(ArrayList<Medicamento> listaMedicamentos) {
        this.listaMedicamentos = listaMedicamentos;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtNome, txtDescricao, txtHorario;
        Button btnConsumido;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtNome = itemView.findViewById(R.id.txtNome);
            txtDescricao = itemView.findViewById(R.id.txtDescricao);
            txtHorario = itemView.findViewById(R.id.txtHorario);
            btnConsumido = itemView.findViewById(R.id.btnConsumido);
        }
    }
}
